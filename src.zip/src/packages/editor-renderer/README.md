# editor-renderer

Headless renderer (server/worker friendly) for `DocumentJson`.

Goal:
- Take a `DocumentJson` (and optional runtime data) and produce page layouts.
- Output adapters: PDF, images, HTML.

This package is intentionally UI-free.
